﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using rabbit_race_assign;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rabbit_race_assign.Tests
{
    [TestClass()]
    public class Form1Tests
    {
        [TestMethod()]
        public void Form1Test()
        {
            Greyhound gry = new Greyhound();
            int y = gry.genNo();
            Assert.IsTrue(true);
        }
        [TestMethod()]
        public void Form2Test()
        {
            Player1 py = new Player1("Mohan",1,1,100);
            if(py.resetBudget(1)==0)
            Assert.IsTrue(true);
        }
    }
}